﻿using CloudDataExportCLI.Data;
using CloudDataExportCLI.Models;
using CloudDataExportCLI.Services;
using CloudDataExportCLI.Util.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Parquet.Data.Rows;
using Polly;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace CloudDataExportCLI
{
    public class App : BackgroundService
    {
        private readonly ILogger<App> _logger;
        private readonly CommandLineOptions _options;
        private readonly IConfiguration _config;
        private readonly IExtractService _extractService;
        private readonly IUploadService _uploadService;
        private readonly IExportLogService _exportLogService;
        private readonly ILogAnalyticsService _logAnalyticsService;
        private readonly IExportConfigurationService _exportConfigurationService;

        public App(
            IExtractService extractService,
            IUploadService uploadService,
            IExportLogService exportLogService, 
            IExportConfigurationService exportConfigurationService,
            ILogAnalyticsService logAnalyticsService,
            IConfiguration config,
            CommandLineOptions options,
            ILogger<App> logger)
        {
            _extractService = extractService;
            _uploadService = uploadService;
            _exportLogService = exportLogService;
            _exportConfigurationService = exportConfigurationService;
            _logAnalyticsService = logAnalyticsService;
            _config = config;
            _options = options;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("STARTING PROCESS");
            //while (!stoppingToken.IsCancellationRequested)
            {
                //var runDelayInSec = 180;
                try
                {
                    ExportConfiguration exportConfig = await _exportConfigurationService.GetExportConfigurationAsync(stoppingToken);
                    
                    await RunAsync(exportConfig, stoppingToken);
                    
                    //await Task.Delay(TimeSpan.FromSeconds(exportConfig.OnPremServiceConfiguration.RunDelayInSec), stoppingToken);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                    //await Task.Delay(TimeSpan.FromSeconds(runDelayInSec), stoppingToken);
                }
            }
        }

        public async Task RunAsync(ExportConfiguration exportConfig, CancellationToken cancellationToken)
        {
            _logger.LogInformation("DataExportTool Running...");
            var processStatusLogBag = new ConcurrentBag<ProcessStatusLog>();
            var processMessage = "";
            
            try
            {
                var currentRowVersion = await _extractService.GetLatestRowVersion(exportConfig.OnPremServiceConfiguration.DBConnectionString, cancellationToken);
                int estNumRowsPerGBRam = 350_000;
                int estMaxMemoryUsedInGB = 2;
                int maxThreads = Environment.ProcessorCount * 2;
                int channelCapacity = maxThreads;
                int batchSize = exportConfig.OnPremServiceConfiguration.BatchSize == 0 ? (int)(1.0 * estNumRowsPerGBRam * estMaxMemoryUsedInGB / channelCapacity) : exportConfig.OnPremServiceConfiguration.BatchSize;
                int numProducers = Math.Max((int)Math.Round(maxThreads * 0.333), 2);
                int numConsumers = Math.Max((int)Math.Round(maxThreads * 0.667), 4);

                var dataExtractChannel = Channel.CreateBounded<DataFragment>(new BoundedChannelOptions(channelCapacity)
                {
                    FullMode = BoundedChannelFullMode.Wait,
                    SingleWriter = false,
                    SingleReader = false,
                });
                var configUploadBag = new ConcurrentBag<ConfigFragment>();

                var extractBulkheadPolicy = Policy.BulkheadAsync(numProducers, int.MaxValue);
                var extractTasks = exportConfig.Datasets.Select((dataset, i) =>
                {
                    return extractBulkheadPolicy.ExecuteAsync(async () =>
                    {
                        Console.WriteLine($"Starting producer {i}");
                        await ExtractDataFragmentsAsync(
                            exportConfig.OnPremServiceConfiguration.DBConnectionString,
                            dataset, 
                            exportConfig, 
                            batchSize, 
                            currentRowVersion,
                            dataExtractChannel.Writer, 
                            processStatusLogBag, 
                            cancellationToken);
                        Console.WriteLine($"Stopping producer {i}");
                    });
                });

                _ = Task.Factory.StartNew(async () =>
                {
                    await Task.WhenAll(extractTasks);
                    Console.WriteLine($"All producers done.");
                    dataExtractChannel.Writer.Complete();
                });

                var dataUploadTasks = Enumerable.Range(0, numConsumers)
                    .Select(async i =>
                    {
                        Console.WriteLine($"Starting consumer {i}");
                        await UploadDataFragmentsAsync(exportConfig, dataExtractChannel.Reader, configUploadBag, cancellationToken);
                        Console.WriteLine($"Stopping consumer {i}");
                    });

                await Task.WhenAll(dataUploadTasks);
                Console.WriteLine($"All consumers done.");

                var configUploadBulkheadPolicy = Policy.BulkheadAsync(numConsumers, int.MaxValue);
                var configUploadTasks = configUploadBag
                    .GroupBy(f => f.Dataset.Id)
                    .ToDictionary(x => x.Key, y => y.ToList())
                    .Select(entry =>
                    {
                        return configUploadBulkheadPolicy.ExecuteAsync(async () =>
                        {
                            await UploadConfigFragmentsAsync(entry.Value, exportConfig, currentRowVersion, processStatusLogBag, cancellationToken);
                        });
                    });

                await Task.WhenAll(configUploadTasks);

                _logger.LogInformation("DataExportTool Completed.");
                processMessage = $"Success";

                dataExtractChannel = null;
                configUploadBag = null;
            }
            catch (Exception e)
            {
                processMessage = $"An error occured: {e.StackTrace}";
            }
            finally
            {
                var processedLogs = processStatusLogBag
                    .GroupBy(p => (p.ConfigFileId, p.DatasetId))
                    .Select(g =>
                    {
                        var timestamps = g.Select(x => x.Timestamp).ToList();
                        return new
                        {
                            ConfigFileId = g.Key.ConfigFileId,
                            TenantId = exportConfig.TenantId,
                            DatasetId = g.Key.DatasetId.ToString(),
                            StartTimestamp = timestamps.Min(),
                            EndTimestamp = timestamps.Max(),
                            DurationInSec = (timestamps.Max() - timestamps.Min()).TotalSeconds,
                            Message = String.Join("  \n", g.OrderBy(x => x.Timestamp).Select(x => x.Message))
                        };
                    })
                    .ToList();
                await _logAnalyticsService.SendLog(processedLogs);
            }
        }

        private async Task ExtractDataFragmentsAsync(
            string dbConnectionString,
            Dataset dataset, 
            ExportConfiguration exportConfig, 
            int batchSize, 
            long currentRowVersion,
            ChannelWriter<DataFragment> channelWriter,
            ConcurrentBag<ProcessStatusLog> processStatusLogBag,
            CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Exporting - Data Fragment for Dataset: {dataset.Name}");
            var uploadGuid = Guid.NewGuid().ToString();
            ExportLog currentLog = await _exportLogService.CreateAsync(dataset.Id, cancellationToken);
            currentLog.Status = ExportLog.StatusType.Extracting;
            await _exportLogService.UpdateAsync(currentLog, cancellationToken);
            processStatusLogBag.Add(new ProcessStatusLog
            {
                ConfigFileId = uploadGuid,
                DatasetId = dataset.Id,
                Message = $"Beginning process for {dataset.Id}",
                Timestamp = DateTime.UtcNow
            });

            int fragmentNum = 0;
            DateTimeOffset extractTimestamp = DateTimeOffset.UtcNow;
            try
            {
                await foreach (Table batch in _extractService.ExtractDataFragmentsAsync(
                    dbConnectionString,
                    dataset,
                    exportConfig.TenantId,
                    batchSize,
                    currentRowVersion,
                    extractTimestamp,
                    cancellationToken))
                {
                    await channelWriter.WriteAsync(new DataFragment
                    {
                        Data = batch,
                        Dataset = dataset,
                        ExtractTimestamp = extractTimestamp,
                        UploadGuid = uploadGuid,
                        FragmentNum = fragmentNum++,
                        Status = FragmentStatus.Success,
                    }, cancellationToken);
                }

                currentLog.Status = ExportLog.StatusType.ExtractSuccess;
                currentLog.Message = fragmentNum == 0 ? "No new data to extract." : "";
                _logger.LogInformation($"{dataset.Name} - Data Extract Successful");
            }
            catch (Exception e)
            {
                currentLog.Status = ExportLog.StatusType.ExtractFailure;
                currentLog.Message = e.ToString();

                await channelWriter.WriteAsync(new DataFragment
                {
                    Data = null,
                    Dataset = dataset,
                    ExtractTimestamp = DateTimeOffset.UtcNow,
                    UploadGuid = uploadGuid,
                    FragmentNum = fragmentNum,
                    Status = FragmentStatus.Failure,
                }, cancellationToken);

                Console.WriteLine($"{dataset.Name} - Data Extract Failed - {e}");
            }
            finally
            {
                await _exportLogService.UpdateAsync(currentLog, cancellationToken);
            }
        }

        private async Task UploadDataFragmentsAsync(ExportConfiguration exportConfig, ChannelReader<DataFragment> reader, ConcurrentBag<ConfigFragment> configFragmentBag, CancellationToken cancellationToken)
        {
            await foreach (var dataFragment in reader.ReadAllAsync(cancellationToken))
            {
                FileLog fileLog = null;
                try
                {
                    if (dataFragment.Status == FragmentStatus.Failure)
                        throw new Exception($"Data fragment failed to upload: {dataFragment.UploadGuid}-{dataFragment.FragmentNum}");

                    fileLog = await _uploadService.UploadDataFragmentAsync(
                    dataFragment.Dataset,
                    dataFragment.Data,
                    exportConfig.BasePath,
                    exportConfig.DataPath,
                    exportConfig.ContainerSASToken,
                    exportConfig.TenantId,
                    exportConfig.TenantName,
                    dataFragment.FragmentNum,
                    cancellationToken);

                    var configFragment = new ConfigFragment
                    {
                        Timestamp = dataFragment.ExtractTimestamp,
                        Dataset = dataFragment.Dataset,
                        UploadGuid = dataFragment.UploadGuid,
                        File = fileLog,
                        Status = FragmentStatus.Success,
                    };
                    configFragmentBag.Add(configFragment);
                }
                catch (Exception e)
                {
                    var configFragment = new ConfigFragment
                    {
                        Timestamp = dataFragment.ExtractTimestamp,
                        Dataset = dataFragment.Dataset,
                        UploadGuid = dataFragment.UploadGuid,
                        File = null,
                        Status = FragmentStatus.Failure,
                    };
                    configFragmentBag.Add(configFragment);

                    Console.WriteLine($"{dataFragment.Dataset.Name} - {dataFragment.UploadGuid} - {dataFragment.FragmentNum} - Data Fragment Upload Failed - {e.StackTrace}");
                }
            }
        }

        private async Task UploadConfigFragmentsAsync(List<ConfigFragment> configFragments, ExportConfiguration exportConfig, long currentRowVersion, ConcurrentBag<ProcessStatusLog> processStatusLogBag, CancellationToken cancellationToken)
        {
            var processMessage = "";
            var configFileFragment = configFragments.OrderBy(c => c.Timestamp).First();
            var fileLogs = configFragments.Select(x => x.File);

            if (!configFragments.All(f => f.Status == FragmentStatus.Success))
            {
                processStatusLogBag.Add(new ProcessStatusLog
                {
                    ConfigFileId = configFileFragment.UploadGuid,
                    DatasetId = configFileFragment.Dataset.Id,
                    Timestamp = DateTime.UtcNow,
                    Message = $"Data upload failed for one or more fragments. Marking export job as failed for {configFileFragment.Dataset.Id}"
                });
                throw new Exception($"Data upload failed for one or more fragments. Marking export job as failed for {configFileFragment.Dataset.Name}");
            }

            _logger.LogInformation($"Uploading - Config File for Dataset: {configFileFragment.Dataset.Name}");
            ExportLog currentLog = await _exportLogService.CreateAsync(configFileFragment.Dataset.Id, cancellationToken);
            currentLog.Status = ExportLog.StatusType.Extracting;
            currentLog.SourceRowVersion = currentRowVersion;
            await _exportLogService.UpdateAsync(currentLog, cancellationToken);

            try
            {
                await _uploadService.UploadConfigFileAsync(
                    configFileFragment.Timestamp,
                    configFileFragment.Dataset.Id.ToString(),
                    configFileFragment.Dataset.PrimaryKeys,
                    exportConfig.BasePath,
                    exportConfig.DataPath,
                    exportConfig.ConfigPath,
                    exportConfig.ContainerSASToken,
                    exportConfig.TenantId,
                    configFileFragment.UploadGuid,
                    fileLogs,
                    cancellationToken
                );

                currentLog.Status = ExportLog.StatusType.UploadSuccess;
                _logger.LogInformation($"{configFileFragment.Dataset.Id} - Data/Config Upload Successful");
                processMessage = $"{configFileFragment.Dataset.Id} - Data/Config Upload Successful";
            }
            catch (Exception e)
            {
                currentLog.Status = ExportLog.StatusType.UploadFailure;
                currentLog.Message = e.ToString();
                Console.WriteLine($"{configFileFragment.Dataset.Id} - Data/Config Upload Failed - {e}");
                processMessage = $"{configFileFragment.Dataset.Id} - Data/Config Upload Failed - {e.StackTrace}";
            }
            finally
            {
                processStatusLogBag.Add(new ProcessStatusLog
                {
                    ConfigFileId = configFileFragment.UploadGuid,
                    DatasetId = configFileFragment.Dataset.Id,
                    Timestamp = DateTime.UtcNow,
                    Message = processMessage
                });
                await _exportLogService.UpdateAsync(currentLog, cancellationToken);
            }
        }
    }
}
