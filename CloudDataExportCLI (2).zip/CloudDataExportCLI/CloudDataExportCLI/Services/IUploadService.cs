﻿using CloudDataExportCLI.Models;
using Parquet.Data.Rows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Services
{
    public interface IUploadService
    {
        public Task<FileLog> UploadDataFragmentAsync(
            Dataset dataset,
            Table batch,
            string basePath,
            string dataPath,
            string containerSasToken,
            string tenantId,
            string tenantName,
            int fragmentNum,
            CancellationToken cancellationToken);

        public Task UploadConfigFileAsync(
            DateTimeOffset timestamp,
            string datasetId,
            IEnumerable<string> primaryKeys,
            string basePath,
            string dataPath,
            string configPath,
            string containerSasToken,
            string tenantId,
            string uploadGuid,
            IEnumerable<FileLog> fileLogs,
            CancellationToken cancellationToken);
    }
}
