﻿using CloudDataExportCLI.Models;
using CloudDataExportCLI.Util;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Services
{
    public class ExportConfigurationService : IExportConfigurationService
    {
        private readonly HttpClient _httpClient;

        public ExportConfigurationService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<ExportConfiguration> GetExportConfigurationAsync(CancellationToken cancellationToken)
        {
            string requestEndpoint = "export/config";
            HttpResponseMessage httpResponse = await _httpClient.GetAsync(requestEndpoint, cancellationToken);
            httpResponse.EnsureSuccessStatusCode();
            var data = await httpResponse.Content.ReadAsStringAsync(cancellationToken);
            return JsonConvert.DeserializeObject<ExportConfiguration>(data);
        }
    }
}
