﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Microsoft.Extensions.Logging;

namespace CloudDataExportCLI.Services
{
    public class LogAnalyticsService : ILogAnalyticsService
    {
        private readonly IConfiguration _config;
        private readonly HttpClient _httpClient;
        private readonly ILogger<LogAnalyticsService> _logger;

        public LogAnalyticsService(HttpClient httpClient, IConfiguration config, ILogger<LogAnalyticsService> logger)
        {
            _httpClient = httpClient;
            _config = config;
            _logger = logger;
        }

        public async Task SendLog(object logObject)
        {
            try
            {
                string url = "https://eos-dev-apim2-eus-01.azure-api.net/eos-dev-apim-monitor-fa-eus01/MonitorHelper";

                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("Accept", "application/json");
                request.Headers.Add("Ocp-Apim-Subscription-Key", "802df2303c3a4447acf9e563a48c0e28");
                request.Headers.Add("logType", "CloudDataExportOnPremService");

                HttpContent httpContent = new StringContent(JsonConvert.SerializeObject(logObject), Encoding.UTF8);
                httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                request.Content = httpContent;

                HttpResponseMessage response = await _httpClient.SendAsync(request);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error logging to Log analytics workspace\n" + e.StackTrace);
            }

        }
    }
}
