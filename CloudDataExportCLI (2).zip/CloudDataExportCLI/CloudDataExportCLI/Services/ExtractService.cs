﻿using Azure.Storage.Blobs;
using CloudDataExportCLI.Data.DAO;
using CloudDataExportCLI.Models;
using CloudDataExportCLI.Util;
using CloudDataExportCLI.Util.Extensions;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Parquet;
using Parquet.Data.Rows;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

namespace CloudDataExportCLI.Services
{
    public class ExtractService : IExtractService
    {
        private readonly ILogger<ExtractService> _logger;
        private readonly IDatasetDAO _datasetDAO;

        public ExtractService(IDatasetDAO datasetDAO, ILogger<ExtractService> logger)
        {
            _logger = logger;
            _datasetDAO = datasetDAO;
        }

        public async IAsyncEnumerable<Table> ExtractDataFragmentsAsync(
            string dbConnectionString,
            Dataset dataset,
            string tenantId,
            int rowBatchSize,
            long currentRowVersion,
            DateTimeOffset currentExportTimestamp,
            [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            var queryDefinition = dataset.Queries.First().Definition;
            //dataset.LastExportRowVersion = 1;
            //dataset.LastExportTimestamp = DateTime.Now.AddDays(-30);
            //init params with required parameters
            var parms = new List<SqlParameter>();
            if (queryDefinition.Contains("@LastExportRowVersion"))
                parms.Add(new SqlParameter("@LastExportRowVersion", dataset.LastExportRowVersion));
            if (queryDefinition.Contains("@CurrentRowVersion"))
                parms.Add(new SqlParameter("@CurrentRowVersion", currentRowVersion));
            if (queryDefinition.Contains("@LastExportDateTime"))
                parms.Add(new SqlParameter("@LastExportDateTime", dataset.LastExportTimestamp));
            if (queryDefinition.Contains("@CurrentExportDateTime"))
                parms.Add(new SqlParameter("@CurrentExportDateTime", currentExportTimestamp));

            // if the dataset query has been updated, make sure the view is created/updated first
            //if (!String.IsNullOrWhiteSpace(dataset.ViewDefinition) && dataset.LastModifiedOn > dataset.LastExportTimestamp)
            //    await _datasetDAO.CreateAlterViewAsync(dataset.ViewDefinition);

            //then export the dataset
            await foreach (Table batch in _datasetDAO.GetDatasetBatchesAsync(dbConnectionString, queryDefinition, rowBatchSize, tenantId, parms, cancellationToken))
                yield return batch;
        }

        public async Task<long> GetLatestRowVersion(string dbConnectionString, CancellationToken cancellationToken)
        {
            return await _datasetDAO.GetLatestRowVersion(dbConnectionString, cancellationToken);
        }
    }
}
