﻿using CloudDataExportCLI.Models;
using System.Threading;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Services
{
    public interface IExportConfigurationService
    {
        public Task<ExportConfiguration> GetExportConfigurationAsync(CancellationToken cancellationToken);
    }
}