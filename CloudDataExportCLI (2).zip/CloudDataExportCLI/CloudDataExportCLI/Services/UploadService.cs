﻿using Azure.Storage.Blobs;
using CloudDataExportCLI.Models;
using CloudDataExportCLI.Util;
using CloudDataExportCLI.Util.Extensions;
using CsvHelper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Parquet;
using Parquet.Data.Rows;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using Azure.Storage.Blobs.Specialized;

namespace CloudDataExportCLI.Services
{
    class UploadService : IUploadService
    {
        private readonly ILogger<UploadService> _logger;
        private readonly IConfiguration _config;

        public UploadService(ILogger<UploadService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

        public async Task<FileLog> UploadDataFragmentAsync(
            Dataset dataset,
            Table batch,
            string basePath,
            string dataPath,
            string containerSasToken,
            string tenantId,
            string tenantName,
            int fragmentNum,
            CancellationToken cancellationToken)
        {
            var uploadDataFolderPath = new Uri(basePath).Append(dataPath, tenantId, dataset.Id.ToString());

            FileLog fileLog = null;
            using (MemoryStream datasetStream = WriteParquetToStream(batch, tenantId))
            {
                
                var filename = $"{DateTime.Now.ToString("yyyyMMdd")}.{DateTime.Now.ToString("HHmm")}.{tenantName}.{dataset.Name}.csv";
                var batchFilePath = $"{dataPath}/{filename}";
                var batchUploadPath = uploadDataFolderPath.Append(batchFilePath);
                await UploadStreamToBlobChunkAsync(datasetStream, new Uri(basePath),containerSasToken, batchFilePath);
                //await UploadStreamToBlobAsync(datasetStream, batchUploadPath, containerSasToken, cancellationToken);

                fileLog = new FileLog
                {
                    FileName = batchFilePath,
                    CreatedDate = DateTime.Now,
                    //MD5Checksum = Convert.ToBase64String(blobInfo.ContentHash),
                };
            }

            return fileLog;
        }

        public async Task UploadConfigFileAsync(
            DateTimeOffset timestamp,
            string datasetId,
            IEnumerable<string> primaryKeys,
            string basePath,
            string dataPath,
            string configPath,
            string containerSasToken,
            string tenantId,
            string uploadGuid,
            IEnumerable<FileLog> fileLogs,
            CancellationToken cancellationToken)
        {
            var uploadConfigFolderPath = new Uri(basePath).Append(configPath);
            var jsonConfigFileName = $"{uploadGuid}.json";
            var jsonConfigLog = new ExportedDatasetLog
            {
                Timestamp = timestamp,
                TenantId = tenantId,
                DatasetId = datasetId,
                PrimaryKeys = primaryKeys,
                ConfigFileName = jsonConfigFileName,
                DataLakePath = dataPath,
                Files = fileLogs,
            };
            using (MemoryStream jsonConfigStream = WriteJsonConfigToStream(jsonConfigLog))
            {
                var jsonConfigUploadPath = uploadConfigFolderPath.Append(jsonConfigFileName);
                await UploadStreamToBlobAsync(jsonConfigStream, jsonConfigUploadPath, containerSasToken, cancellationToken);
            }
        }

        private static async Task<Azure.Storage.Blobs.Models.BlobContentInfo> UploadStreamToBlobAsync(MemoryStream stream, Uri uploadPath, string containerSasToken, CancellationToken cancellationToken)
        {
            BlobClient blobClient = new BlobClient(uploadPath, new Azure.AzureSasCredential(containerSasToken));
                        

            var blobResp = await Utils.DoRetryAsync(async () =>
            {
                stream.Position = 0;
                return await blobClient.UploadAsync(stream, cancellationToken);
            }, TimeSpan.FromSeconds(3), maxAttemptCount: 3);

            return blobResp.Value;
        }

        public async Task UploadStreamToBlobChunkAsync(MemoryStream stream, Uri uploadPath, string containerSasToken,string filename, int size = 8000000)
        {
            var _container = new BlobContainerClient(uploadPath, new Azure.AzureSasCredential(containerSasToken)); ;
            //_container.CreateIfNotExists();
            var blob = _container.GetBlockBlobClient(filename);

            // local variable to track the current number of bytes read into buffer
            int bytesRead;

            // track the current block number as the code iterates through the file
            int blockNumber = 0;

            // Create list to track blockIds, it will be needed after the loop
            List<string> blockList = new List<string>();

            do
            {
                // increment block number by 1 each iteration
                blockNumber++;

                // set block ID as a string and convert it to Base64 which is the required format
                string blockId = $"{blockNumber:0000000}";
                string base64BlockId = Convert.ToBase64String(Encoding.UTF8.GetBytes(blockId));

                // create buffer and retrieve chunk
                byte[] buffer = new byte[size];
                bytesRead = await stream.ReadAsync(buffer, 0, size);

                // Upload buffer chunk to Azure
                await blob.StageBlockAsync(base64BlockId, new MemoryStream(buffer, 0, bytesRead), null);

                // add the current blockId into our list
                blockList.Add(base64BlockId);

                // While bytesRead == size it means there is more data left to read and process
            } while (bytesRead == size);

            // add the blockList to the Azure which allows the resource to stick together the chunks
            await blob.CommitBlockListAsync(blockList);

            // make sure to dispose the stream once your are done
            stream.Dispose();
            
        }

        private static MemoryStream WriteParquetToStream(Table dataset, string tenantId)
        {
            try
            {
                var stream = new MemoryStream();
                var res = dataset.ToString("j");
                var data = jsontoCSV(res, ",", tenantId);
                StreamWriter writer = new StreamWriter(stream);
                writer.Write(data);
                stream.Position = 0;
                return stream;
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.StackTrace);
                return null;
            }
        }

        public static DataTable jsonStringToTable(string jsonContent, string tenantId)
        {
            var str = "[" + jsonContent + "]";
            str = str.Replace(System.Environment.NewLine, ",");
            DataTable dt = JsonConvert.DeserializeObject<DataTable>(str);

            return dt;
        }

        public static string jsontoCSV(string content, string delimeter, string tenantId)
        {
            StringWriter csvString = new StringWriter();
            using (var csv = new CsvWriter(csvString, System.Globalization.CultureInfo.InvariantCulture))
            {
                using (var dt = jsonStringToTable(content, tenantId))
                {
                    foreach (DataColumn column in dt.Columns)
                    {
                        csv.WriteField(column.ColumnName);
                    }
                    csv.NextRecord();

                    foreach (DataRow row in dt.Rows)
                    {
                        for (var i = 0; i < dt.Columns.Count; i++)
                        {
                            csv.WriteField(row[i]);
                        }
                        csv.NextRecord();
                    }
                }
            }
            return csvString.ToString();
        }

        private static MemoryStream WriteJsonConfigToStream(ExportedDatasetLog jsonConfigLog)
        {
            MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(jsonConfigLog)));
            stream.Position = 0;
            return stream;
        }
    }
}
