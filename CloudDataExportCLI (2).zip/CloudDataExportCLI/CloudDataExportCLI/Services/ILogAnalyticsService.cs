﻿using System.Threading.Tasks;

namespace CloudDataExportCLI.Services
{
    public interface ILogAnalyticsService
    {
        Task SendLog(object logObject);
    }
}