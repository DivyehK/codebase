﻿using CloudDataExportCLI.Models;
using Parquet.Data.Rows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Services
{
    public interface IExtractService
    {
        public IAsyncEnumerable<Table> ExtractDataFragmentsAsync(
            string dbConnectionString,
            Dataset dataset,
            string tenantId,
            int rowBatchSize,
            long currentRowVersion,
            DateTimeOffset currentExportTimestamp,
            CancellationToken cancellationToken);
        public Task<long> GetLatestRowVersion(
            string dbConnectionString,
            CancellationToken cancellationToken);
    }
}
