﻿using CloudDataExportCLI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Services
{
    public interface IExportLogService
    {
        public Task<ExportLog> CreateAsync(Guid datasetId, CancellationToken cancellationToken);
        public Task<ExportLog> UpdateAsync(ExportLog log, CancellationToken cancellationToken);
        public Task ExportCompleteHook(IEnumerable<string> datasetIds, CancellationToken cancellationToken);
    }
}
