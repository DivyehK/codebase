﻿using CloudDataExportCLI.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Services
{
    class ExportLogService: IExportLogService
    {
        private readonly IConfiguration _config;
        private readonly HttpClient _httpClient;

        public ExportLogService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<ExportLog> CreateAsync(Guid datasetId, CancellationToken cancellationToken)
        {
            string requestEndpoint = $"export/log/{datasetId}";
            HttpResponseMessage httpResponse = await _httpClient.PostAsync(requestEndpoint, null, cancellationToken);
            httpResponse.EnsureSuccessStatusCode();

            return JsonConvert.DeserializeObject<ExportLog>(await httpResponse.Content.ReadAsStringAsync(cancellationToken));
        }

        public async Task<ExportLog> UpdateAsync(ExportLog log, CancellationToken cancellationToken)
        {
            string requestEndpoint = $"export/log/{log.Id}";
            var data = new StringContent(JsonConvert.SerializeObject(log), Encoding.UTF8, "application/json");
            HttpResponseMessage httpResponse = await _httpClient.PutAsync(requestEndpoint, data, cancellationToken);
            httpResponse.EnsureSuccessStatusCode();

            return JsonConvert.DeserializeObject<ExportLog>(await httpResponse.Content.ReadAsStringAsync(cancellationToken));
        }

        public async Task ExportCompleteHook(IEnumerable<string> datasetIds, CancellationToken cancellationToken)
        {
            string requestEndpoint = $"export/hook";
            var data = new StringContent(JsonConvert.SerializeObject(
                new
                {
                    DatasetIds = datasetIds,
                }), Encoding.UTF8, "application/json");
            HttpResponseMessage httpResponse = await _httpClient.PostAsync(requestEndpoint, data, cancellationToken);
            httpResponse.EnsureSuccessStatusCode();
        }
    }
}
