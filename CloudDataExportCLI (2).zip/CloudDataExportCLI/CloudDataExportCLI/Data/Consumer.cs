﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Data
{
    public class Consumer<T>
        where T : class, new()
    {
        private readonly BlockingCollection<T> collection;
        private readonly Func<T, Task> consumingFunction;

        public Consumer(BlockingCollection<T> collection, Func<T, Task> consumingFunction)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection is required");
            }

            if (collection == null)
            {
                throw new ArgumentNullException("consumingFunction is required");
            }

            this.collection = collection;
            this.consumingFunction = consumingFunction;
        }

        public async void Consume()
        {
            while (!this.collection.IsAddingCompleted)
            {
                T instance;
                this.collection.TryTake(out instance, (int)TimeSpan.FromMinutes(1).TotalMilliseconds);

                if (instance != null)
                {
                    await this.consumingFunction(instance);
                }
                else
                {
                    throw new InvalidOperationException("Unable to get item from collection.");
                }
            }
        }
    }
}
