﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Data.DAO
{
    public interface IDatasetDAO
    {
        public IAsyncEnumerable<Parquet.Data.Rows.Table> GetDatasetBatchesAsync(string dbConnectionString, string batchSql, int batchSize, string tenantId, IEnumerable<SqlParameter> parms, CancellationToken cancellationToken);
        public Task<long> GetLatestRowVersion(string dbConnectionString, CancellationToken cancellationToken);
        //public Task CreateAlterViewAsync(string query);
    }
}
