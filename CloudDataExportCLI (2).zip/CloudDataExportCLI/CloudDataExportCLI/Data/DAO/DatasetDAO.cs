﻿using Microsoft.Extensions.Configuration;
using Parquet.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Data.DAO
{
    public class DatasetDAO : IDatasetDAO
    {
        private readonly IConfiguration _config;

        public DatasetDAO(IConfiguration config)
        {
            _config = config;
        }

        public async IAsyncEnumerable<Parquet.Data.Rows.Table> GetDatasetBatchesAsync(string dbConnectionString, string cmdText, int batchSize, string tenantId, IEnumerable<SqlParameter> parms, [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            using (var connection = new SqlConnection(dbConnectionString))
            {
                await connection.OpenAsync(cancellationToken);
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = cmdText;
                    command.CommandType = CommandType.Text;
                    command.CommandTimeout = 0;//120;
                    command.Parameters.AddRange(parms.ToArray());

                    using (var reader = await command.ExecuteReaderAsync(cancellationToken))
                    {
                        // Get the column name and data type information for building up the parquet schema
                        var columns = Enumerable.Range(0, reader.FieldCount)
                            .Select(o => new { FieldName = reader.GetName(o), DataType = reader.GetFieldType(o) })
                            .ToList();

                        var dataFields = columns.Select(c =>
                        {
                            Type columnType;
                            if (c.DataType.IsClass)
                                columnType = c.DataType;
                            else
                            {
                                Type type;
                                if (c.DataType == typeof(DateTime))
                                    type = typeof(DateTimeOffset);
                                //the numerical cases can be removed once Databricks RT uses Spark 3.2.0 which supports unsigned numbers
                                //https://github.com/apache/spark/blob/master/sql/core/src/main/scala/org/apache/spark/sql/execution/datasources/parquet/ParquetSchemaConverter.scala#L128
                                else if (c.DataType == typeof(byte))
                                    type = typeof(short);
                                else if (c.DataType == typeof(ushort))
                                    type = typeof(int);
                                else if (c.DataType == typeof(uint))
                                    type = typeof(long);
                                else if (c.DataType == typeof(ulong))
                                    type = typeof(double);
                                else
                                    type = c.DataType;

                                columnType = typeof(Nullable<>).MakeGenericType(type);
                            }

                            var fieldType = typeof(DataField<>).MakeGenericType(columnType);

                            return (DataField)Activator.CreateInstance(fieldType, c.FieldName);
                        }).ToList();

                        dataFields.Add(new DataField<string>("TenantId"));
                        dataFields.Add(new DataField<DateTimeOffset>("ExportTimestamp"));

                        var dataset = new Parquet.Data.Rows.Table(new Schema(dataFields));
                        DateTimeOffset exportTimestamp = DateTimeOffset.UtcNow;

                        // Read each record from the database
                        while (await reader.ReadAsync(cancellationToken))
                        {
                            // Convert the current record into an object array, swapping DBNULL values for null before adding
                            // the record to the parquet dataset
                            object ProcessValue(int o)
                            {
                                var value = reader.GetValue(o);
                                var type = reader.GetFieldType(o);

                                if (value == DBNull.Value)
                                    return null;
                                if (type == typeof(DateTime))
                                    return new DateTimeOffset((DateTime)value);
                                //can remove these once Databricks updates to Spark 3.2.0 which supports unsigned numbers
                                if (type == typeof(byte))
                                    return Convert.ToInt16((byte)value);
                                if (type == typeof(ushort))
                                    return Convert.ToInt32((ushort)value);
                                if (type == typeof(uint))
                                    return Convert.ToInt64((uint)value);
                                if (type == typeof(ulong))
                                    return Convert.ToDouble((ulong)value);

                                return value;
                            }

                            var row = Enumerable.Range(0, reader.FieldCount)
                                .Select(ProcessValue)
                                .ToList();

                            //Guid tryParseGuid = Guid.Parse(tenantId); /// test will throw exception if invalid
                            if (String.IsNullOrEmpty(tenantId))
                                throw new Exception();

                            row.Add(tenantId);
                            row.Add(exportTimestamp);

                            dataset.Add(new Parquet.Data.Rows.Row(row));

                            //removing batch size chunking will be handled by PutBlocbAsync
                            // if (dataset.Count == batchSize)
                            // {
                            //     yield return dataset;
                            //     dataset = new Parquet.Data.Rows.Table(new Schema(dataFields));
                            //     exportTimestamp = DateTimeOffset.UtcNow;
                            // }
                        }

                        if (dataset.Count > 0)
                        {
                            yield return dataset;
                        }
                        command.Parameters.Clear();
                    }
                }
            }
        }

        public async Task<long> GetLatestRowVersion(string dbConnectionString, CancellationToken cancellationToken)
        {
            using (var connection = new SqlConnection(dbConnectionString))
            {
                await connection.OpenAsync(cancellationToken);
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT convert(bigint, @@DBTS)";
                    command.CommandType = CommandType.Text;
                    command.CommandTimeout = 120;

                    using (var reader = await command.ExecuteReaderAsync(cancellationToken))
                    {
                        await reader.ReadAsync(cancellationToken);
                        return (long)reader.GetValue(0);
                    }
                }
            }
        }

        private async Task<List<Parquet.Data.DataColumn>> GetRecordsAsParquetDataColumnsAsync(string cmdText, SqlParameter[] parms, CancellationToken cancellationToken)
        {
            using (var connection = new SqlConnection(_config.GetValue<string>("EoStarDbConnectionString")))
            {
                try
                {
                    await connection.OpenAsync(cancellationToken);
                    var dataColumns = new List<Parquet.Data.DataColumn>();
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = cmdText;
                        command.CommandType = CommandType.Text;
                        command.CommandTimeout = 120;
                        command.Parameters.AddRange(parms);

                        using (var reader = await command.ExecuteReaderAsync(cancellationToken))
                        {
                            // Get the column name and data type information for building up the parquet schema
                            var columns = Enumerable.Range(0, reader.FieldCount)
                                .Select(o => new { FieldName = reader.GetName(o), DataType = reader.GetFieldType(o) })
                                .ToList();

                            var dataFields = new List<DataField>();
                            var columnTypes = new List<Type>();
                            var columnData = new List<List<object>>();

                            columns.ForEach(c =>
                            {
                                Type columnType;
                                if (c.DataType.IsClass)
                                    columnType = c.DataType;
                                else
                                {
                                    Type type;
                                    if (c.DataType == typeof(DateTime))
                                        type = typeof(DateTimeOffset);
                                    else
                                        type = c.DataType;

                                    columnType = typeof(Nullable<>).MakeGenericType(type);
                                }

                                var dataFieldType = typeof(DataField<>).MakeGenericType(columnType);

                                dataFields.Add((DataField)Activator.CreateInstance(dataFieldType, c.FieldName));
                                columnTypes.Add(columnType);
                                columnData.Add(new List<object>());
                            });

                            // Read each record from the database
                            while (await reader.ReadAsync(cancellationToken))
                            {
                                for (var i = 0; i < reader.FieldCount; i++)
                                {
                                    var value = reader.GetValue(i);
                                    var type = reader.GetFieldType(i);

                                    if (value == DBNull.Value)
                                        value =  null;
                                    if (type == typeof(DateTime) && value != null)
                                        value =  new DateTimeOffset((DateTime)value);

                                    // slot each value in proper column
                                    columnData[i].Add(value);
                                }
                            }

                            if (columnData.All(c => c.Count > 0))
                            {
                                for (int i = 0; i < dataFields.Count; i++)
                                {
                                    var singleColumnData = columnData[i];
                                    Array data = Array.CreateInstance(columnTypes[i], singleColumnData.Count);
                                    for (int j = 0; j < singleColumnData.Count; j++)
                                    {
                                        data.SetValue(singleColumnData[j], j);
                                    }
                                    dataColumns.Add(new Parquet.Data.DataColumn(dataFields[i], data));
                                }
                            }
                            command.Parameters.Clear();
                        }
                        return dataColumns;
                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine(e);
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        //public async Task CreateAlterViewAsync(string query)
        //{
        //    using (var connection = new SqlConnection(_config.GetValue<string>("EoStarDbConnectionString")))
        //    {
        //        try
        //        {
        //            await connection.OpenAsync();

        //            using (var command = connection.CreateCommand())
        //            {
        //                command.CommandText = query;
        //                command.CommandType = CommandType.Text;
        //                await command.ExecuteNonQueryAsync();
        //            }
        //        }
        //        catch (SqlException e)
        //        {
        //            Console.WriteLine(e);
        //            throw;
        //        }
        //        finally
        //        {
        //            connection.Close();
        //        }
        //    }

        //}
    }
}
