﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Data
{
    public class Producer<T>
       where T : class, new()
    {
        private readonly BlockingCollection<T> collection;
        private readonly Func<IAsyncEnumerable<T>> producingFunction;

        public Producer(Func<IAsyncEnumerable<T>> producingFunction, BlockingCollection<T> collection)
        {
            if (producingFunction == null)
            {
                throw new ArgumentNullException("producingFunction is required");
            }

            if (collection == null)
            {
                throw new ArgumentNullException("collection is required");
            }

            this.collection = collection;
            this.producingFunction = producingFunction;
        }

        public async void StartProduction()
        {
            await foreach(T producingResult in this.producingFunction())
                if (producingFunction != default(T))
                    this.collection.TryAdd(producingResult, (int)TimeSpan.FromSeconds(10).TotalMilliseconds);

            this.collection.CompleteAdding();
        }
    }
}
