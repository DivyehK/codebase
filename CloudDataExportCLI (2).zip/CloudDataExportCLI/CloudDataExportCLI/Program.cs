﻿using CloudDataExportCLI.Data.DAO;
using CloudDataExportCLI.Services;
using CloudDataExportCLI.Util.Extensions;
using CommandLine;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.EventLog;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace CloudDataExportCLI
{
    class Program
    {
        static async Task<int> Main(string[] args) =>
            await Parser.Default.ParseArguments<CommandLineOptions>(args)
                .MapResult(async (opts) =>
                {
                    await CreateHostBuilder(args, opts).Build().RunAsync();
                    return 0;
                },
                errs => Task.FromResult(-1)); // Invalid arguments

        public static IHostBuilder CreateHostBuilder(string[] args, CommandLineOptions opts) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureLogging(configureLogging => configureLogging.AddFilter<EventLogLoggerProvider>(level => level >= LogLevel.Information))
                .ConfigureAppConfiguration((hostContext, builder) =>
                { 
                    //builder.SetBasePath(Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName))
                       // .AddJsonFile("config.json", optional: false);
                        //fordev below-->
                    builder.SetBasePath(Directory.GetCurrentDirectory())
                        .AddJsonFile("config.json", optional: false);
                })
                .ConfigureServices((hostContext, services) =>
                {
                    services.AddTransient(_ => hostContext.Configuration)
                        .AddTransient<IDatasetDAO, DatasetDAO>()
                        .AddTransient<IExportLogService, ExportLogService>()
                        .AddTransient<ILogAnalyticsService, LogAnalyticsService>()
                        .AddTransient<IExportConfigurationService, ExportConfigurationService>()
                        .AddTransient<IExtractService, ExtractService>()
                        .AddTransient<IUploadService, UploadService>()
                        .AddHttpClientCustom<IExportLogService, ExportLogService>(hostContext.Configuration)
                        .AddHttpClientCustom<IExportConfigurationService, ExportConfigurationService>(hostContext.Configuration);
                    services.AddHttpClient<ILogAnalyticsService, LogAnalyticsService>();
                    services.AddSingleton(opts);
                    services.AddHostedService<App>()
                        .Configure<EventLogSettings>(config =>
                        {
                            config.LogName = "eoStar Data Export Service";
                            config.SourceName = "eoStar Data Export Service Source";
                        });
                })
            .UseWindowsService(options =>
            {
                options.ServiceName = "eoStar Data Export Service";
            });
    }

    public class CommandLineOptions
    {
        [Value(index: 0, Required = false, HelpText = "Path to watch.")]
        public string Path { get; set; }

        [Option(shortName: 'e', longName: "extensions", Required = false, HelpText = "Valid image extensions.", Default = new[] { "png", "jpg", "jpeg" })]
        public string[] Extensions { get; set; }

        [Option(shortName: 'c', longName: "confidence", Required = false, HelpText = "Minimum confidence.", Default = 0.9f)]
        public float Confidence { get; set; }
    }
}
