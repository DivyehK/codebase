﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Models
{
    public class ConfigFragment
    {
        public DateTimeOffset Timestamp { get; set; }
        public Dataset Dataset { get; set; }
        public string UploadGuid { get; set; }
        public FileLog File { get; set; }
        public FragmentStatus Status { get; set; }
    }
}
