﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Models
{
    public class ExportConfiguration
    {
        public string ContainerSASToken { get; set; }
        public string TenantId { get; set; }
        public string TenantName { get; set; }
        public string ServiceContainerName { get; set; }
        public string BasePath { get; set; }
        public string DataPath { get; set; }
        public string ConfigPath { get; set; }
        public int RowBatchSize { get; set; }
        public DateTimeOffset LastExportTimestamp { get; set; }
        public IEnumerable<Dataset> Datasets { get; set; }
        public OnPremServiceConfiguration OnPremServiceConfiguration { get; set; }
    }
}
