﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Models
{
    public class OnPremServiceConfiguration
    {
        public Guid Id { get; set; }
        public string DBConnectionString { get; set; }
        public int BatchSize { get; set; } = 0;
        public int RunDelayInSec { get; set; } = 180;
        public bool IsActive { get; set; } = true;
        public Guid TenantId { get; set; }
    }
}
