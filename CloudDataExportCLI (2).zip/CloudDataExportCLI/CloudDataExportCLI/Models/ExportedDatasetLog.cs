﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Models
{
    public class ExportedDatasetLog
    {
        public DateTimeOffset Timestamp { get; set; }
        public string TenantId { get; set; }
        public string DatasetId { get; set; }
        public IEnumerable<string> PrimaryKeys { get; set; }
        public string ConfigFileName { get; set; }
        public string DataLakePath { get; set; }
        public IEnumerable<FileLog> Files { get; set; }
    }

    public class FileLog
    {
        public string FileName { get; set; }
        public DateTimeOffset CreatedDate { get; set; }
        public string MD5Checksum { get; set; }
    }
}
