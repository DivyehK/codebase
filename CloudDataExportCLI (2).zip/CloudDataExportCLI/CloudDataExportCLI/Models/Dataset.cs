﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Models
{
    public class Dataset
    {
        public enum DatasetTypeEnum
        {
            TimeSeries = 0,
            Atomic = 1
        }

        public Guid Id { get; set; }
        public DateTimeOffset LastModifiedOn { get; set; }
        public string Name { get; set; }
        public DatasetTypeEnum DatasetType { get; set; }
        public IEnumerable<string> PrimaryKeys { get; set; }
        public IEnumerable<Query> Queries { get; set; }
        public DateTimeOffset LastExportTimestamp { get; set; }
        public long LastExportRowVersion { get; set; }
    }
}
