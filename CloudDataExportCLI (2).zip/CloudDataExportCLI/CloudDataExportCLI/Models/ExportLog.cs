﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Models
{
    public class ExportLog
    {
        public enum StatusType
        {
            Created = 0,
            Extracting = 1,
            ExtractSuccess = 2,
            ExtractFailure = 3,
            Uploading = 4,
            UploadSuccess = 5,
            UploadFailure = 6,
        }

        public Guid Id { get; set; }
        public StatusType Status { get; set; }
        public string Message { get; set; }
        public long SourceRowVersion { get; set; }
    }
}
