﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Models
{
    public class Query
    {
        public Guid? Id { get; set; }
        public string Definition { get; set; }
        public int? Version { get; set; }
        public Guid DatasetId { get; set; }
        public Guid TargetSystemId { get; set; }
    }
}
