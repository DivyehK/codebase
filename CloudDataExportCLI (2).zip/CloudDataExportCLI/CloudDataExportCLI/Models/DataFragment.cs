﻿using Parquet.Data.Rows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDataExportCLI.Models
{
    public class DataFragment
    {
        public Dataset Dataset { get; set; }
        public Table Data { get; set; }
        public DateTimeOffset ExtractTimestamp { get; set; }
        public string UploadGuid { get; set; }
        public int FragmentNum { get; set; }
        public FragmentStatus Status { get; set; }
    }

    public enum FragmentStatus
    {
        Success = 0,
        Failure = 1,
    }
}
