﻿$taskAction = New-ScheduledTaskAction `
    -Execute 'C:\Program Files\CloudDataExportTool\bin\CloudDataExportCLI.exe'

$taskTrigger = New-ScheduledTaskTrigger -Daily -At 12AM

# The name of your scheduled task.
$taskName = "CloudDataExportToolTask"

# Describe the scheduled task.
$description = "Runs the data export tool console app"

# Register the scheduled task
#Register-ScheduledTask `
#    -TaskName $taskName `
#    -Action $taskAction `
#    -Trigger $taskTrigger `
#    -Description $description

Set-ScheduledTask `
    -TaskName $taskName `
    -Action $taskAction `
    -Trigger $taskTrigger

Get-ScheduledTaskInfo -TaskName CloudDataExportToolTask